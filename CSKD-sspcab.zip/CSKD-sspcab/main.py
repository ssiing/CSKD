import torch
from dataset import get_data_transforms
from torchvision.datasets import ImageFolder
import numpy as np
import random
from torch import optim
import os
from torch.utils.data import DataLoader
from resnet import resnet18, resnet34, resnet50, wide_resnet50_2
from resnet2 import resnet181, resnet341, resnet501, wide_resnet50_21
from dataset import MVTecDataset
import torch.backends.cudnn as cudnn
import argparse
from test import evaluation, print_current_performance, print_current_performance1
from torch.nn import functional as F
import torchvision.utils as vutils


def count_parameters(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def loss_fucntion(a, b):
    # mse_loss = torch.nn.MSELoss()
    cos_loss = torch.nn.CosineSimilarity()
    loss = 0
    for item in range(len(a) - 1):
        # print(a[item].shape)
        # print(b[item].shape)
        # loss1 += 0.1*mse_loss(a[item], b[item])
        loss += torch.mean(1 - cos_loss(a[item].view(a[item].shape[0], -1),
                                        b[item].view(b[item].shape[0], -1)))
    return loss


def train(obj_names, args):
    if not os.path.exists(args.checkpoint_path):
        os.makedirs(args.checkpoint_path)

    global auroc_px, auroc_sp, aupro_px, loss
    for obj_name in obj_names:
        print(obj_name)

        device = 'cuda' if torch.cuda.is_available() else 'cpu'
        print(device)

        data_transform, gt_transform = get_data_transforms(args.image_size, args.image_size)
        run_name = 'APMKD_train_' + str(args.image_size) + "_" + obj_name + '_'

        train_data = ImageFolder(root=args.data_path + obj_name + '/train', transform=data_transform)
        test_data = MVTecDataset(root=args.data_path + obj_name, transform=data_transform, gt_transform=gt_transform,
                                 phase="test")

        test_dataloader = torch.utils.data.DataLoader(test_data, batch_size=1, shuffle=False)
        train_dataloader = torch.utils.data.DataLoader(train_data, batch_size=args.bs, shuffle=True)

        T_encoder = wide_resnet50_2(pretrained=True)
        T_encoder = T_encoder.to(device)

        T_encoder.eval()
        S_encoder = wide_resnet50_21(pretrained=False)
        S_encoder = S_encoder.to(device)
        optimizer = torch.optim.Adam(list(S_encoder.parameters()), lr=args.lr, betas=(0.5, 0.999))

        for epoch in range(args.epochs):

            S_encoder.train()
            loss_list = []

            for img, label in train_dataloader:
                img = img.to(device)
                inputs = T_encoder(img)
                outputs = S_encoder(img)  # bn(inputs))
                loss = loss_fucntion(inputs, outputs)
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()
                loss_list.append(loss.item())

            print_current_performance(epoch + 1, loss)
            print('epoch [{}/{}], loss:{:.4f}'.format(epoch + 1, args.epochs, np.mean(loss_list)))

            if (epoch + 1) % 10 == 0:
                auroc_px, auroc_sp, ap, ap_pixel, aupro_px = evaluation(T_encoder, S_encoder, test_dataloader, device,
                                                                        obj_name)

                print_current_performance1(auroc_px, auroc_sp, ap, ap_pixel, aupro_px, obj_name)

                print('Pixel Auroc:{:.3f}, Sample Auroc{:.3f}'
                      ',Sample Ap{:.3f}, Pixel Ap:{:.3f}, Pixel Aupro{:.3f}'.format(auroc_px, auroc_sp, ap, ap_pixel,
                                                                                    aupro_px))

            if (epoch + 1) % 10 == 0:
             
                torch.save(S_encoder.state_dict(), os.path.join(args.checkpoint_path,
                                                                run_name + str(epoch + 1) + '_' + "se.pckl"))


if __name__ == "__main__":

    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--obj_id', default=2, type=int)
    parser.add_argument('--bs', default=16, type=int)
    parser.add_argument('--lr', default=0.005, type=float)
    parser.add_argument('--epochs', default=200, type=int)
    parser.add_argument('--data_path', default='D:/ssy/data/', type=str)
    parser.add_argument('--checkpoint_path', default='./checkpoints/', type=str)
    parser.add_argument('--image_size', default=256, type=int)

    args = parser.parse_args()

    obj_batch = [
                 ['capsule'],
                 ['bottle'],
                 ['carpet'],
                 ['leather'],
                 ['pill'],
                 ['transistor'],
                 ['tile'],
                 ['cable'],
                 ['zipper'],
                 ['toothbrush'],
                 ['metal_nut'],
                 ['hazelnut'],
                 ['screw'],
                 ['grid'],
                 ['wood'],
                 ]

    if int(args.obj_id) == -1:
        obj_list = [
                    'capsule',
                    'bottle',
                    'carpet',
                    'leather',
                    'pill',
                    'transistor',
                    'tile',
                    'cable',
                    'zipper',
                    'toothbrush',
                    'metal_nut',
                    'hazelnut',
                    'screw',
                    'grid',
                    'wood',
                    ]
        picked_classes = obj_list
    else:
        picked_classes = obj_batch[int(args.obj_id)]

    setup_seed(111)
    train(picked_classes, args)
