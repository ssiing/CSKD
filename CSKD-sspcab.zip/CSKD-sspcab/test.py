import torch
from dataset import get_data_transforms, load_data
from torchvision.datasets import ImageFolder
import numpy as np
import random
from random import sample
from torch.utils.data import DataLoader
from resnet import resnet18, resnet34, resnet50, wide_resnet50_2
from resnet2 import resnet181, resnet341, resnet501, wide_resnet50_21
from dataset import MVTecDataset
from torch.nn import functional as F
from sklearn.metrics import roc_auc_score, average_precision_score
import cv2
import time
from sklearn.metrics import auc
from scipy.spatial.distance import mahalanobis
from scipy.ndimage import gaussian_filter
from skimage import morphology
from skimage import measure
from skimage.segmentation import mark_boundaries
import matplotlib
import pickle
from sklearn.metrics import precision_recall_curve
import matplotlib.pyplot as plt
from sklearn.metrics import auc
from sklearn.metrics import roc_curve
from skimage import measure
import pandas as pd
from numpy import ndarray
from statistics import mean
from scipy.ndimage import gaussian_filter
import os
from sklearn import manifold
from matplotlib.ticker import NullFormatter
from scipy.spatial.distance import pdist
import matplotlib
import pickle
from sklearn import manifold


def cal_anomaly_map(fs_list, ft_list, out_size=224, amap_mode='mul'):
    if amap_mode == 'mul':
        anomaly_map = np.ones([out_size, out_size])
    else:
        anomaly_map = np.zeros([out_size, out_size])
    a_map_list = []

    for i in range(len(ft_list)-1):
        fs = fs_list[i]
        ft = ft_list[i]
        # fs_norm = F.normalize(fs, p=2)
        # ft_norm = F.normalize(ft, p=2)
        a_map = 1 - F.cosine_similarity(fs, ft)
        a_map = torch.unsqueeze(a_map, dim=1)
        a_map = F.interpolate(a_map, size=out_size, mode='bilinear', align_corners=True)
        a_map = a_map[0, 0, :, :].to('cpu').detach().numpy()
        a_map_list.append(a_map)
        if amap_mode == 'mul':
            anomaly_map *= a_map
        else:
            anomaly_map += a_map

    return anomaly_map, a_map_list


def show_cam_on_image(img, anomaly_map):
    # if anomaly_map.shape != img.shape:
    #    anomaly_map = cv2.applyColorMap(np.uint8(anomaly_map), cv2.COLORMAP_JET)
    cam = np.float32(anomaly_map) / 255 + np.float32(img) / 255
    cam = cam / np.max(cam)

    return np.uint8(255 * cam)


def min_max_norm(image):
    a_min, a_max = image.min(), image.max()
    return (image - a_min) / (a_max - a_min)


def cvt2heatmap(gray):
    heatmap = cv2.applyColorMap(np.uint8(gray), cv2.COLORMAP_JET)

    return heatmap


def print_current_performance(epoch, loss_list):
    message = '   '
    log_name = r"train_log.txt"
    dt = time.gmtime()
    message += str(dt.tm_year) + "-" + str(dt.tm_mon) + "-" + str(dt.tm_mday) + "-" + str(dt.tm_hour + 8) + ":" + str(
        dt.tm_min) + ":" + str(dt.tm_sec)
    message += "epoch: %.3f###" % epoch
    message += 'loss_list: %.3f###' % loss_list

    with open(log_name, "a") as log_file:
        log_file.write('%s\n' % message)


def print_current_performance1(auroc_px, auroc_sp, ap, ap_piexl, aupro_px, _class_):
    message = '   '
    log_name = r"train_log1.txt"
    dt = time.gmtime()
    message += str(dt.tm_year) + "-" + str(dt.tm_mon) + "-" + str(dt.tm_mday) + "-" + str(
        dt.tm_hour + 8) + ":" + str(
        dt.tm_min) + ":" + str(dt.tm_sec) + str(_class_)
    message += 'Sample Auroc: %.3f###' % auroc_sp
    message += 'Sample Ap: %.3f' % ap
    message += "Pixel Auroc: %.3f###" % auroc_px
    message += 'Pixel Ap: %.3f' % ap_piexl
    message += 'Pixel Aupro: %.3f' % aupro_px

    with open(log_name, "a") as log_file:
        log_file.write('%s\n' % message)


def print_current_performance2(auroc_px, auroc_sp, ap, ap_piexl, aupro_px, _class_, epoch):
    message = '   '
    log_name = r"test_log.txt"
    dt = time.gmtime()
    message += str(dt.tm_year) + "-" + str(dt.tm_mon) + "-" + str(dt.tm_mday) + "-" + str(
        dt.tm_hour + 8) + ":" + str(dt.tm_min) + ":" + str(dt.tm_sec) + ":" + str(_class_) + ":" + str(epoch) + ":"
    message += 'Sample Auroc: %.3f###' % auroc_sp
    message += 'Sample Ap: %.3f' % ap
    message += "Pixel Auroc: %.3f###" % auroc_px
    message += 'Pixel Ap: %.3f' % ap_piexl
    message += 'Pixel Aupro: %.3f' % aupro_px

    with open(log_name, "a") as log_file:
        log_file.write('%s\n' % message)


def write_results_to_file(run_name, image_auc, pixel_auc, image_ap, pixel_ap, pixel_aupro):
    if not os.path.exists('./outputs/'):
        os.makedirs('./outputs/')

    fin_str = "img_auc," + run_name
    for i in image_auc:
        fin_str += "," + str(np.round(i, 3))
    fin_str += "," + str(np.round(np.mean(image_auc), 3))
    fin_str += "\n"
    fin_str += "pixel_auc," + run_name
    for i in pixel_auc:
        fin_str += "," + str(np.round(i, 3))
    fin_str += "," + str(np.round(np.mean(pixel_auc), 3))
    fin_str += "\n"
    fin_str += "img_ap," + run_name
    for i in image_ap:
        fin_str += "," + str(np.round(i, 3))
    fin_str += "," + str(np.round(np.mean(image_ap), 3))
    fin_str += "\n"
    fin_str += "pixel_ap," + run_name
    for i in pixel_ap:
        fin_str += "," + str(np.round(i, 3))
    fin_str += "," + str(np.round(np.mean(pixel_ap), 3))
    fin_str += "\n"
    fin_str += "pixel_aupro," + run_name
    for i in pixel_aupro:
        fin_str += "," + str(np.round(i, 3))
    fin_str += "," + str(np.round(np.mean(pixel_aupro), 3))
    fin_str += "\n"
    fin_str += "--------------------------\n"

    with open("./outputs/results.txt", 'a+') as file:
        file.write(fin_str)


def compute_pro(masks: ndarray, amaps: ndarray, num_th: int = 200) -> None:
    """Compute the area under the curve of per-region overlaping (PRO) and 0 to 0.3 FPR
    Args:
        category (str): Category of product
        masks (ndarray): All binary masks in test. masks.shape -> (num_test_data, h, w)
        amaps (ndarray): All anomaly maps in test. amaps.shape -> (num_test_data, h, w)
        num_th (int, optional): Number of thresholds
    """

    assert isinstance(amaps, ndarray), "type(amaps) must be ndarray"
    assert isinstance(masks, ndarray), "type(masks) must be ndarray"
    assert amaps.ndim == 3, "amaps.ndim must be 3 (num_test_data, h, w)"
    assert masks.ndim == 3, "masks.ndim must be 3 (num_test_data, h, w)"
    assert amaps.shape == masks.shape, "amaps.shape and masks.shape must be same"
    assert set(masks.flatten()) == {0, 1}, "set(masks.flatten()) must be {0, 1}"
    assert isinstance(num_th, int), "type(num_th) must be int"

    df = pd.DataFrame(columns=["pro", "fpr", "threshold"])
    binary_amaps = np.zeros_like(amaps, dtype=np.bool_)

    min_th = amaps.min()
    max_th = amaps.max()
    delta = (max_th - min_th) / num_th

    for th in np.arange(min_th, max_th, delta):
        binary_amaps[amaps <= th] = 0
        binary_amaps[amaps > th] = 1

        pros = []
        for binary_amap, mask in zip(binary_amaps, masks):
            for region in measure.regionprops(measure.label(mask)):
                axes0_ids = region.coords[:, 0]
                axes1_ids = region.coords[:, 1]
                tp_pixels = binary_amap[axes0_ids, axes1_ids].sum()
                pros.append(tp_pixels / region.area)

        inverse_masks = 1 - masks
        fp_pixels = np.logical_and(inverse_masks, binary_amaps).sum()
        fpr = fp_pixels / inverse_masks.sum()
        df_new_row = pd.DataFrame({"pro": [mean(pros)], "fpr": [fpr], "threshold": [th]})
        df = pd.concat([df, df_new_row])

    # Normalize FPR from 0 ~ 1 to 0 ~ 0.3
    df = df[df["fpr"] < 0.3]
    df["fpr"] = df["fpr"] / df["fpr"].max()

    pro_auc = auc(df["fpr"], df["pro"])
    return pro_auc


def evaluation(T_encoder, S_encoder, dataloader, device, _class_=None):

    S_encoder.eval()
    gt_list_px = []
    pr_list_px = []
    gt_list_sp = []
    pr_list_sp = []
    aupro_list = []

    with torch.no_grad():
        for img, gt, label, _ in dataloader:

            img = img.to(device)
            inputs = T_encoder(img)
            outputs = S_encoder(img)
            anomaly_map, _ = cal_anomaly_map(inputs, outputs, img.shape[-1], amap_mode='a')
            anomaly_map = gaussian_filter(anomaly_map, sigma=4)
            gt[gt > 0.5] = 1
            gt[gt <= 0.5] = 0
            if label.item() != 0:
                aupro_list.append(compute_pro(gt.squeeze(0).cpu().numpy().astype(int),
                                              anomaly_map[np.newaxis, :, :]))

            gt_list_px.extend(gt.cpu().numpy().astype(int).ravel())
            pr_list_px.extend(anomaly_map.ravel())
            gt_list_sp.append(np.max(gt.cpu().numpy().astype(int)))
            pr_list_sp.append(np.max(anomaly_map))

        auroc_px = round(roc_auc_score(gt_list_px, pr_list_px), 3)
        auroc_sp = round(roc_auc_score(gt_list_sp, pr_list_sp), 3)
        ap = round(average_precision_score(gt_list_sp, pr_list_sp), 3)
        ap_pixel = round(average_precision_score(gt_list_px, pr_list_px), 3)

    return auroc_px, auroc_sp, ap, ap_pixel, round(np.mean(aupro_list), 3)


def test(obj_names, args):
    global run_name

    obj_auroc_pixel_list = []
    obj_aupro_pixel_list = []
    obj_ap_pixel_list = []
    obj_ap_image_list = []
    obj_auroc_image_list = []

    for obj_name in obj_names:
        print(obj_name)
        device = 'cuda' if torch.cuda.is_available() else 'cpu'

        data_transform, gt_transform = get_data_transforms(args.image_size, args.image_size)
        run_name = 'APMKD_train_' + str(args.image_size) + "_" + obj_name + '_' + str(args.epochs) + "_"

        # ano_map = show_cam_on_image(img, ano_map)
        if not os.path.exists(args.eval_dir):
            os.makedirs(args.eval_dir)

        test_data = MVTecDataset(root=args.data_path + obj_name, transform=data_transform, gt_transform=gt_transform,
                                 phase="test")
        test_dataloader = torch.utils.data.DataLoader(test_data, batch_size=1, shuffle=False)

        T_encoder = wide_resnet50_2(pretrained=True)
        T_encoder = T_encoder.to(device)
        T_encoder.eval()

        S_encoder = wide_resnet50_21(pretrained=False)
        S_encoder = S_encoder.to(device)

        S_encoder.load_state_dict(
            torch.load(os.path.join(args.checkpoint_path, run_name + "se.pckl"),
                       map_location='cuda:0'))

        print("Pretrained models have been loaded.")

        auroc_px, auroc_sp, ap, ap_piexl, aupro_px = evaluation(T_encoder, S_encoder, test_dataloader, device)

        obj_auroc_pixel_list.append(auroc_px)
        obj_aupro_pixel_list.append(aupro_px)
        obj_auroc_image_list.append(auroc_sp)
        obj_ap_image_list.append(ap)
        obj_ap_pixel_list.append(ap_piexl)

        print(obj_name)
        print("AUC Image:  " + str(auroc_sp))
        print("AP Image:  " + str(ap))
        print("AUC Pixel:  " + str(auroc_px))
        print("AP Pixel:  " + str(ap_piexl))
        print("Aupro Pixel:  " + str(aupro_px))
        print("==============================")

        print_current_performance2(auroc_px, auroc_sp, ap, ap_piexl, aupro_px, obj_name, args.epochs)

    print(run_name)
    print("AUC Image mean:  " + str(np.mean(obj_auroc_image_list)))
    print("AP Image mean:  " + str(np.mean(obj_ap_image_list)))
    print("AUC Pixel mean:  " + str(np.mean(obj_auroc_pixel_list)))
    print("AP Pixel mean:  " + str(np.mean(obj_ap_pixel_list)))
    print("AuPro Pixel mean:  " + str(np.mean(obj_aupro_pixel_list)))
    write_results_to_file(run_name, obj_auroc_image_list, obj_auroc_pixel_list, obj_ap_image_list,
                          obj_ap_pixel_list,
                          obj_aupro_pixel_list)


def visualization(obj_names, args):

    for obj_name in obj_names:
        print(obj_name)
        device = 'cuda' if torch.cuda.is_available() else 'cpu'

        data_transform, gt_transform = get_data_transforms(args.image_size, args.image_size)
        run_name = 'APMKD_train_' + str(args.image_size) + "_" + obj_name + '_' + str(args.epochs) + "_"

        test_data = MVTecDataset(root=args.data_path + obj_name, transform=data_transform, gt_transform=gt_transform,
                                 phase="test")
        test_dataloader = torch.utils.data.DataLoader(test_data, batch_size=1, shuffle=False)

        T_encoder = wide_resnet50_2(pretrained=True)
        T_encoder = T_encoder.to(device)
        T_encoder.eval()

        S_encoder = wide_resnet50_21(pretrained=False)
        S_encoder = S_encoder.to(device)

        S_encoder.load_state_dict(
            torch.load(os.path.join(args.checkpoint_path, run_name + "se.pckl"),
                       map_location='cuda:0'))

        print("Pretrained models have been loaded.")

        gt_list_sp = []
        pr_list_sp = []
        gt_list_px = []
        pr_list_px = []
        with torch.no_grad():
            for i, (img, gt, label, _) in enumerate(test_dataloader):
                if label.item() == 0:
                    continue
                S_encoder.eval()

                img = img.to(device)
                inputs = T_encoder(img)
                outputs = S_encoder(img)

                anomaly_map, _ = cal_anomaly_map(inputs, outputs, img.shape[-1], amap_mode='a')
                anomaly_map = gaussian_filter(anomaly_map, sigma=4)

                gt_list_px.extend(gt.cpu().numpy().astype(int).ravel())
                pr_list_px.extend(anomaly_map.ravel())
                gt_list_sp.append(np.max(gt.cpu().numpy().astype(int)))
                pr_list_sp.append(np.max(anomaly_map))

                ano_map = min_max_norm(anomaly_map)
                ano_map1 = cvt2heatmap(ano_map * 255)

                img = cv2.cvtColor(img.permute(0, 2, 3, 1).cpu().numpy()[0] * 255, cv2.COLOR_BGR2RGB)
                img1 = np.uint8(min_max_norm(img) * 255)
                img = cv2.cvtColor(img1, cv2.COLOR_RGB2BGR)
                gt = gt.cpu().numpy().astype(int)[0][0] * 255
                if not os.path.exists('./results_all/' + '/' + obj_name + '_' + str(args.epochs)):
                    os.makedirs('./results_all/' + '/' + obj_name + '_' + str(args.epochs))
                ano_map1 = show_cam_on_image(img1, ano_map1)
                cv2.imwrite('./results_all/' + obj_name + '_' + str(args.epochs) + '/' + str(i) + '_' + 'ad.png',
                            ano_map1)
                cv2.imwrite('./results_all/' + obj_name + '_' + str(args.epochs) + '/' + str(i) + '_' + 'gt.png',
                            gt)
                cv2.imwrite('./results_all/' + obj_name + '_' + str(args.epochs) + '/' + str(i) + '_' + 'org.png',
                            img1)
                if not os.path.exists(args.save_path + '/' + obj_name + '_' + str(args.epochs)):
                    os.makedirs(args.save_path + '/' + obj_name + '_' + str(args.epochs))

                save_dir = args.save_path + '/' + obj_name + '_' + str(args.epochs)
                vis(i, gt, ano_map, img, save_dir, obj_name)


def vis(i, gt, ano_map, img, save_dir, obj_name):
    vmax = ano_map.max() * 255.
    vmin = ano_map.min() * 255.
    heat_map = ano_map * 255
    fig_img, ax_img = plt.subplots(1, 3, figsize=(12, 3))
    fig_img.subplots_adjust(right=0.9)
    norm = matplotlib.colors.Normalize(vmin=vmin, vmax=vmax)
    for ax_i in ax_img:
        ax_i.axes.xaxis.set_visible(False)
        ax_i.axes.yaxis.set_visible(False)
    ax_img[0].imshow(img)
    ax_img[0].title.set_text('Image')
    ax_img[1].imshow(gt, cmap='gray')
    ax_img[1].title.set_text('GroundTruth')
    ax = ax_img[2].imshow(heat_map, cmap='jet', norm=norm)
    ax_img[2].imshow(img, cmap='gray', interpolation='none')
    ax_img[2].imshow(heat_map, cmap='jet', alpha=0.5, interpolation='none')
    ax_img[2].title.set_text('Predicted heat map')
    left = 0.92
    bottom = 0.15
    width = 0.015
    height = 1 - 2 * bottom
    rect = [left, bottom, width, height]
    cbar_ax = fig_img.add_axes(rect)
    cb = plt.colorbar(ax, shrink=0.6, cax=cbar_ax, fraction=0.046)
    cb.ax.tick_params(labelsize=8)
    font = {
        'family': 'serif',
        'color': 'black',
        'weight': 'normal',
        'size': 8,
    }
    cb.set_label('Anomaly Score', fontdict=font)
    fig_img.savefig(
        os.path.join(save_dir, obj_name + '_{}'.format(i)),
        dpi=100)
    plt.cla()
    plt.close("all")


if __name__ == "__main__":

    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--obj_id', default=0, type=int)
    parser.add_argument('--data_path', default='E:/database/MVTec/', type=str)
    parser.add_argument('--checkpoint_path', default='./checkpoints/', type=str)
    parser.add_argument('--save_path', default='./results/', type=str)
    parser.add_argument('--eval_dir', default='./eval/', type=str)
    parser.add_argument('--epochs', default=10, type=int)
    parser.add_argument('--image_size', default=256, type=int)

    args = parser.parse_args()

    obj_batch = [
                 ['carpet'],
                 ['leather'],
                 ['transistor'],
                 ['toothbrush'],
                 ['grid'],
                 ['wood'],
                 ]

    if int(args.obj_id) == -1:

        obj_list = [
                    'carpet',
                    'leather',
                    'transistor',
                    'toothbrush',
                    'grid',
                    'wood',
                    ]

        picked_classes = obj_list
    else:
        picked_classes = obj_batch[int(args.obj_id)]

    test(picked_classes, args)
